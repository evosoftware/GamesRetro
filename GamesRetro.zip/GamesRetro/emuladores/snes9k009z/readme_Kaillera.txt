Snes9k v0.09z by g0ebish

Snes9x with Kaillera support.

Instructions:

-This is a Work In Progress version, bugs remains.
-Zipped roms don't work with Kaillera
-Some games desynch (eg: Ultimate Mortal Kombat 3), problem also occurs with original snes9x & zsnes netplay systems.
-Desynch CAN occurs if sram files are not the same on every side.

1) extract the content of the archive anywhere

2) execute snes9k.exe

(!!!important!!!)
3) first time you play, load a game (this is to locate roms dir) 
(!!!important!!!)


4) goto file --> play kaillera game

5) continue as usual on kaillera

If the step 3 is not respected, no game will appear in kaillera.

Note: while in game, actual player 1 can press F12 to swap player 1 & 2 controls

Check for forum and latest version at: http://snes9k.fr.st or http://goebish.free.fr/snes9k
Have fun, please report bugs to goebish@gmail.com.
